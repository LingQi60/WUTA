//base-library
#include <ros/ros.h>
#include <iostream>
#include <string.h>
#include <typeinfo>
#include <vector>
#include <std_msgs/String.h>
//point-msg
#include "geometry_msgs/Point32.h"
#include "sensor_msgs/PointCloud.h"
#include "sensor_msgs/PointCloud2.h"
#include <sensor_msgs/point_cloud_conversion.h>

// //self-msg
#include "union_detect_msgs/BoundingBox.h"
#include "union_detect_msgs/BoundingBoxes.h"
#include "union_detect_msgs/LidarBox.h"
#include "union_detect_msgs/LidarBoxes.h"
#include "union_detect_msgs/Cone.h"
#include "fsd_common_msgs/Cone.h"

//image dispose
#include "sensor_msgs/Image.h"
#include <sensor_msgs/image_encodings.h>
#include <cv_bridge/cv_bridge.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
//namespace
using namespace std;
using namespace cv;
//self-structure
struct point3d {
    float x = 0;
    float y = 0;
    float z = 0 ;
    float m = 1;
};
struct point2d {
    double u = 0;
    double v = 0;
};
struct _3dbox {
    int x = 0;
    int y = 0;
    int z = 0;
    int w = 0;
    int h = 0;
    int l =0 ;
};
struct _2dbox {
    int x1 = 0;
    int y1 = 0;
    int x2 = 0;
    int y2 = 0;
    string cls = "";
};
struct _index {
		string cls = "";
		int x = 0;
		int y = 0;
		int z = 0;
	};

//global variable
cv::Mat images;
vector<_2dbox> m_Img2dBoxArr;
_2dbox m_Img2dBox;
vector<point2d> m_Point2dArr;
point2d m_Point2d;
vector<point3d> m_Point3dArr;
point3d m_point3d;
vector<_index> m_ResultIndexArr;
_index m_ResultIndex;
vector<_3dbox> m_lidar3dBoxArr;
_3dbox m_lidar3dBox;
vector<_2dbox> m_lidar2dBoxArr;
_2dbox m_lidar2dBox;
//subscriber and publisher
ros::Subscriber boundingboxesSubscriber_;
ros::Subscriber pointsSubscriber_;
ros::Subscriber foshan_pointsSubscriber_;
ros::Subscriber imagesSubscriber_;
ros::Publisher objectspublisher_;
ros::Publisher mappingpublisher_;

//the images result of yolo 
void imagescallback(const sensor_msgs::ImageConstPtr msg)
{
  // ROS_INFO("This is the black: imagescallback");
  cv_bridge::CvImagePtr cv_ptr;
  cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
  images = cv_ptr->image;
  return;
}

//the 2d boundingboxes result of yolo
void boundingboxcallback(const union_detect_msgs::BoundingBoxes &boundingBoxesResults_)
{
  // ROS_INFO("This is the black: boundingboxcallback");
  if(!boundingBoxesResults_.bounding_boxes.empty())
  {
    for(int i = 0; i < boundingBoxesResults_.bounding_boxes.size(); i++)
    {
        m_Img2dBox.cls = boundingBoxesResults_.bounding_boxes[i].Class;
        m_Img2dBox.x1 = boundingBoxesResults_.bounding_boxes[i].xmin;
        m_Img2dBox.x2 = boundingBoxesResults_.bounding_boxes[i].xmax;
        m_Img2dBox.y1 = boundingBoxesResults_.bounding_boxes[i].ymin;
        m_Img2dBox.y2 = boundingBoxesResults_.bounding_boxes[i].ymax;
        m_Img2dBoxArr.push_back(m_Img2dBox);
    }
    // if(!m_Img2dBoxArr.empty())
    // {
    //   ROS_INFO("The size of m_Img2dBoxArr is %d",m_Img2dBoxArr.size());
    //   ROS_INFO("");
    // } 
  }
  return;
}

// //the center point result of point cluster
// void pointcallback(const sensor_msgs::PointCloud &cluster_)
// {
//   ROS_INFO("This is the black: pointcallback");
//   if(!cluster_.points.empty())
//   {
//     for(int i = 0; i < cluster_.points.size(); i++)
//     {
//       m_point3d.x=cluster_.points[i].x;
//       m_point3d.y=cluster_.points[i].y;
//       m_point3d.z=cluster_.points[i].z;
//       m_point3d.m=1;
//       m_Point3dArr.push_back(m_point3d);
//     } 
//     if(!m_Point3dArr.empty())
//     {
//       ROS_INFO("The size of m_Point3dArr is %d",m_Point3dArr.size());
//       ROS_INFO("");
//     }     
//   }
//   return;
// }

void foshan_pointcallback(const sensor_msgs::PointCloud2 &cloud_msg)
{
  // ROS_INFO("This is the black: foshan_pointcallback");
  sensor_msgs::PointCloud clouddate;
  sensor_msgs::convertPointCloud2ToPointCloud(cloud_msg, clouddate);
  // ROS_INFO("___________________________________");
  if(!clouddate.points.empty())
  {
    for(int i = 0; i < clouddate.points.size(); i++)
    {
      m_point3d.x = clouddate.points[i].x;
      m_point3d.y = clouddate.points[i].y;
      m_point3d.z = clouddate.points[i].z;
      m_point3d.m = 1;
      
      // ROS_INFO("(%f,%f,%f)",clouddate.points[i].x,clouddate.points[i].y,clouddate.points[i].z);
      // ROS_INFO("_____________________________________________");
      m_Point3dArr.push_back(m_point3d);
      // ROS_INFO("(%f,%f,%f)",m_Point3dArr[i].x,m_Point3dArr[i].y,m_Point3dArr[i].z);
    } 
    // if(!m_Point3dArr.empty())
    // {
    //   ROS_INFO("The size of m_Point3dArr is %d",m_Point3dArr.size());
    //   ROS_INFO("");
    //   ROS_INFO("___________________________________");
    // }     
  }
  return;

}
//transform point-cloud into image
void point_Tr_velo_to_img()
{
  // ROS_INFO("");
  // ROS_INFO("______________________________________");
  // ROS_INFO("This is the black: point_Tr_velo_to_img");
  Mat Y;
  Mat X;
  // double m_cam[4][1];
  // double m_img[3][1];
  // double m_velo_to_cam[4][4]={{3.8158970452755070e-02, 5.4152121511705176e-02, 9.9780330762619107e-01, 9.0777367107424778e-01},
  // {-9.9919547021841981e-01, 1.4399786627030453e-02, 3.7430715196039188e-02, 3.4333227555668117e-02},
  // {-1.2341202087996384e-02, -9.9842886270423770e-01, 5.4658035549639994e-02, -7.7453526167384212e-01},
  // { 0., 0., 0., 1.}};
  // double m_cam_to_img[3][4]={{1.1018550478406341e+03, 0., 1.0374826496205360e+03,0.},
  // {0.,1.1072674653585802e+03, 5.8028032885303412e+02, 0.},
  // { 0., 0., 1. ,0.}};
  // double m_count = 0.;
  // double m_x[4][1];

  // if (!m_Point3dArr.empty())
  // {
  //   for(int i = 0; i < m_Point3dArr.size(); i++)
  //   {
  //     m_x[0][0] = m_Point3dArr[i].x;
  //     m_x[1][0] = m_Point3dArr[i].y;
  //     m_x[2][0] = m_Point3dArr[i].z;
  //     m_x[3][0] = 1;

  //     for(int j = 0; j < 4;j++)
  //     {
  //       for(int k = 0; k < 4; k++)
  //       {
  //         m_count = m_count + m_velo_to_cam[j][k] * m_x[k][0];
  //       }
  //       m_cam[j][0] = m_count;
  //       m_count = 0;
  //     }

  //     for(int j = 0; j < 3;j++)
  //     {
  //       for(int k = 0; k < 4; k++)
  //       {
  //         m_count = m_count + m_cam_to_img[j][k] * m_cam[k][0];
  //       }
  //       m_img[j][0] = m_count;
  //       m_count = 0;
  //     }

  //     m_Point2d.u =int(m_img[0][0]/m_img[2][0]);
  //     m_Point2d.v =int(m_img[1][0]/m_img[2][0]);
  //     m_Point2dArr.push_back(m_Point2d);
  //     circle(images, Point(m_Point2d.u, m_Point2d.v), 3, cv::Scalar(0, 255, 120), -1);
  //   }
  //   cv_bridge::CvImage cvImage;
  //   cvImage.header.stamp = ros::Time::now();
  //   cvImage.header.frame_id = "point-image-mapping";
  //   cvImage.encoding = sensor_msgs::image_encodings::BGR8;
  //   cvImage.image = images;
  //   mappingpublisher_.publish(*cvImage.toImageMsg());

  // }

  Mat velo_to_cam0 = (Mat_<double>(4,4)<< 
  3.8158970452755070e-02, 5.4152121511705176e-02, 9.9780330762619107e-01, 9.0777367107424778e-01,
  -9.9919547021841981e-01, 1.4399786627030453e-02, 3.7430715196039188e-02, 3.4333227555668117e-02,
  -1.2341202087996384e-02, -9.9842886270423770e-01, 5.4658035549639994e-02, -7.7453526167384212e-01, 
  0., 0., 0., 1. );
  
  Mat cam_to_img0 = (Mat_<double>(3, 4) <<  
  1.1018550478406341e+03, 0., 1.0374826496205360e+03,0.,
  0.,1.1072674653585802e+03, 5.8028032885303412e+02, 0.,
  0., 0., 1. ,0.);
  // ROS_INFO("______________________________________");
  if (!m_Point3dArr.empty())
  {

    for(int i = 0; i < m_Point3dArr.size(); i++)
    {
      X = (Mat_<double>(4,1)<< m_Point3dArr[i].x, m_Point3dArr[i].y, m_Point3dArr[i].z, m_Point3dArr[i].m);
      cout<<"\n\n\n"<<X;
      // cout<<"\n"<<"("<<m_Point3dArr[i].x<<","<<m_Point3dArr[i].y<<","<<m_Point3dArr[i].z<<")";
      Y = cam_to_img0 * velo_to_cam0 * X;
      cout<<"\n"<<Y;
      // m_Point2d.u =int(Y.at<double>(0,0)/Y.at<double>(2,0));
      // m_Point2d.v =int(Y.at<double>(1,0)/Y.at<double>(2,0));
      m_Point2d.u = Y.at<double>(0,0)/Y.at<double>(2,0);
      m_Point2d.v = Y.at<double>(1,0)/Y.at<double>(2,0);
      // ROS_INFO("(%f,%f)",m_Point2d.u,m_Point2d.v);
  
      if( m_Point2d.u < 0)
      {
        m_Point2d.u = -m_Point2d.u;
      }
      if( m_Point2d.v < 0)
      {
        m_Point2d.v = -m_Point2d.v;
      }

      if(m_Point2d.u > 0 && m_Point2d.u < 1920 && m_Point2d.v > 0 && m_Point2d.v < 1920)
      {
        m_Point2dArr.push_back(m_Point2d);
        if(!images.empty())
        {
          circle(images, Point(int(m_Point2d.u), int(m_Point2d.v)), 3, cv::Scalar(0, 255, 120), -1);
        }
      }
    }
    // ROS_INFO("______________________________________");
    cv_bridge::CvImage cvImage;
    cvImage.header.stamp = ros::Time::now();
    cvImage.header.frame_id = "point-image-mapping";
    cvImage.encoding = sensor_msgs::image_encodings::BGR8;
    cvImage.image = images;
    mappingpublisher_.publish(*cvImage.toImageMsg());
    // ROS_INFO("The map has been published");
    // ROS_INFO("");
    // if(!m_Point2dArr.empty())
    // {
    //   ROS_INFO("The size of m_Point2dArr is %d",m_Point2dArr.size());
    //   ROS_INFO("");
    // }
  }
  return;
}

//judge whether points in the 2d boundingboxes
void is_point_in_2dbbox()
{
  // ROS_INFO("This is the black: is_point_in_2dbbox");
  if(!m_Img2dBoxArr.empty() && !m_Point2dArr.empty() && !m_Point3dArr.empty())
  {
    for (int i = 0; i < m_Img2dBoxArr.size(); i++)
    {
      for (int j = 0; j < m_Point2dArr.size(); j++)
      {
        if (m_Point2dArr[j].u > m_Img2dBoxArr[i].x1
          && m_Point2dArr[j].u < m_Img2dBoxArr[i].x2
          && m_Point2dArr[j].v > m_Img2dBoxArr[i].y1
          && m_Point2dArr[j].v < m_Img2dBoxArr[i].y2)
        {
          m_ResultIndex.cls = m_Img2dBoxArr[i].cls;
          m_ResultIndex.x = m_Point3dArr[j].x;
          m_ResultIndex.y = m_Point3dArr[j].y;
          m_ResultIndex.z = m_Point3dArr[j].z;
          m_ResultIndexArr.push_back(m_ResultIndex);
        }
      }
    }
    // if(!m_ResultIndexArr.empty())
    // {
    //   ROS_INFO("The size of m_ResultIndexArr is %d",m_ResultIndexArr.size());
    //   ROS_INFO("");
    // }
  }
  return;
}

//the 3d boundingboxes result of point cluster
void boxcallback(const union_detect_msgs::LidarBoxes &lidarBoxesResults_)
{
  if(!lidarBoxesResults_.lidarbox.empty())
  {
    ROS_INFO("This is the black: boundingboxcallback");
    for(int i = 0; i < lidarBoxesResults_.lidarbox.size(); i++)
    {
      m_lidar3dBox.x = lidarBoxesResults_.lidarbox[i].x;
      m_lidar3dBox.y = lidarBoxesResults_.lidarbox[i].y;
      m_lidar3dBox.z = lidarBoxesResults_.lidarbox[i].z;
      m_lidar3dBox.w = lidarBoxesResults_.lidarbox[i].w;
      m_lidar3dBox.h = lidarBoxesResults_.lidarbox[i].h;
      m_lidar3dBox.l = lidarBoxesResults_.lidarbox[i].l;
      m_lidar3dBoxArr.push_back(m_lidar3dBox);
    }
    if(!m_lidar3dBoxArr.empty())
    {
      ROS_INFO("The size of m_lidar3dBoxArr is %d",m_lidar3dBoxArr.size());
      ROS_INFO("");
    }  
  }
  return;
}

//transform 3d boundingboxes into 2d boundingboxes of point cluster
void box_Tr_velo_to_img()
{
  ROS_INFO("");
  ROS_INFO("______________________________________");
  ROS_INFO("This is the black: point_Tr_velo_to_img");
  Mat Y1;
  Mat Y2;
  Mat X1;
  Mat X2;

  Mat velo_to_cam0 = (Mat_<double>(4,4)<< 
  3.8158970452755070e-02, 5.4152121511705176e-02, 9.9780330762619107e-01, 9.0777367107424778e-01,
  -9.9919547021841981e-01, 1.4399786627030453e-02, 3.7430715196039188e-02, 3.4333227555668117e-02,
  -1.2341202087996384e-02, -9.9842886270423770e-01, 5.4658035549639994e-02, -7.7453526167384212e-01, 
  0., 0., 0., 1. );

  Mat cam_to_img0 = (Mat_<double>(3, 4) <<  
  1.1018550478406341e+03, 0., 1.0374826496205360e+03,0,
  0.,1.1072674653585802e+03, 5.8028032885303412e+02, 0,
  0., 0., 1. ,0);

  if (!m_lidar3dBoxArr.empty())
  {
    for(int i = 0; i < m_lidar3dBoxArr.size(); i++)
    {
      X1 = (Mat_<double>(4,1)<< m_lidar3dBoxArr[i].x - m_lidar3dBoxArr[i].w/2, 
                                m_lidar3dBoxArr[i].y - m_lidar3dBoxArr[i].l/2, 
                                m_lidar3dBoxArr[i].z - m_lidar3dBoxArr[i].h/2, 1);
      X2 = (Mat_<double>(4,1)<< m_lidar3dBoxArr[i].x + m_lidar3dBoxArr[i].w/2, 
                                m_lidar3dBoxArr[i].y + m_lidar3dBoxArr[i].l/2, 
                                m_lidar3dBoxArr[i].z + m_lidar3dBoxArr[i].h/2, 1);
      Y1 = cam_to_img0 * velo_to_cam0 * X1;
      Y2 = cam_to_img0 * velo_to_cam0 * X2;
      m_lidar2dBox.x1 = int(Y1.at<double>(0,0)/Y1.at<double>(2,0));
      m_lidar2dBox.y1 = int(Y1.at<double>(1,0)/Y1.at<double>(2,0));
      m_lidar2dBox.x2 = int(Y2.at<double>(0,0)/Y2.at<double>(2,0));
      m_lidar2dBox.y2 = int(Y2.at<double>(1,0)/Y2.at<double>(2,0));
      if(m_lidar2dBox.x1 > 0 && m_lidar2dBox.x1 < 1500 && m_lidar2dBox.y1 > 0 && m_lidar2dBox.y1 < 1500
      && m_lidar2dBox.x2 > 0 && m_lidar2dBox.x2 < 1500 && m_lidar2dBox.y2 > 0 && m_lidar2dBox.y2 < 1500)
      {
        m_lidar2dBoxArr.push_back(m_lidar2dBox);
      }
    }
    if(!m_lidar2dBoxArr.empty())
    {
      ROS_INFO("The size of m_lidar2dBoxArr is %d",m_lidar2dBoxArr.size());
      ROS_INFO("");
    }
  }
  return;
}

//calculate the iou between 2d boundingboxes of point cluster and the one of yolo
void iou_calculate()
{
  ROS_INFO("This is the black: iou_calculate");
	float in_w = 0;
	float in_h = 0;
	float s_intersection = 0;
	float s_union = 0;
  float iou;
  float iou_threshold =0.5;
  if(!m_Img2dBoxArr.empty() && !m_lidar2dBoxArr.empty())
  {
    for(int i = 0; i < m_Img2dBoxArr.size(); i++)
    {
      for(int j = 0; j < m_lidar2dBoxArr.size(); j++)
      {
        in_w = float(min(m_Img2dBoxArr[i].x2, m_lidar2dBoxArr[j].x2) - max(m_Img2dBoxArr[i].x1, m_lidar2dBoxArr[j].x1));
        in_h = float(min(m_Img2dBoxArr[i].y2, m_lidar2dBoxArr[j].y2) - max(m_Img2dBoxArr[i].y1, m_lidar2dBoxArr[j].y1));
        s_intersection = in_w * in_h;
        if (in_w < 0 || in_h < 0)
        {
          s_intersection = 0;
        }
        s_union = float((m_Img2dBoxArr[i].x2 - m_Img2dBoxArr[i].x1) * (m_Img2dBoxArr[i].y2 - m_Img2dBoxArr[i].y1)
                  + (m_lidar2dBoxArr[j].x2 - m_lidar2dBoxArr[j].x1) * (m_lidar2dBoxArr[j].y2 - m_lidar2dBoxArr[j].y1));
        iou = s_intersection / s_union;
        if(iou > iou_threshold)
        {
          m_ResultIndex.cls = m_Img2dBoxArr[i].cls;
          m_ResultIndex.x = m_Point3dArr[j].x;
          m_ResultIndex.y = m_Point3dArr[j].y;
          m_ResultIndex.z = m_Point3dArr[j].z;
          m_ResultIndexArr.push_back(m_ResultIndex);
        }
      }
    }
    if(!m_ResultIndexArr.empty())
    {
      ROS_INFO("The size of m_ResultIndexArr is %d",m_ResultIndexArr.size());
      ROS_INFO("");
    }
  }
  return;
}

//publish the result of union-detect
void object_publish() 
{	
  // ROS_INFO("This is the black: object_publish");
  if(!m_ResultIndexArr.empty())
  {
    fsd_common_msgs::Cone cone;
    for(int i = 0; i < m_ResultIndexArr.size(); i++)
    {
      cone.position.x = m_ResultIndexArr[i].x;
      cone.position.y = m_ResultIndexArr[i].y;
      cone.position.z = m_ResultIndexArr[i].z;
      cone.color.data = m_ResultIndexArr[i].cls;
      objectspublisher_.publish(cone);
      // ROS_INFO("The result of union-detect has been published");
      // ROS_INFO("");
    }
  }
  return;
} 

//clear out all variables
void object_clear()
{
  // ROS_INFO("This is the black: object_clear");
  m_Img2dBoxArr.clear();
  m_Point3dArr.clear();
  m_Point2dArr.clear();
  m_ResultIndexArr.clear();
  if(m_Img2dBoxArr.empty() && m_Point3dArr.empty() && m_Point2dArr.empty() && m_ResultIndexArr.empty())
  {
    // ROS_INFO("The variables have been cleaned");
  }
  // ROS_INFO("______________________________________");
  // ROS_INFO(""); 
  return;                                 
}

//the main funtion
void union_detector(std::string mode)
{
  if(mode == "point")
  {
    point_Tr_velo_to_img();
    // is_point_in_2dbbox();
    // object_publish();
    object_clear();
  }
  else if(mode == "3dbox")
  {
    // box_Tr_velo_to_img();
    // // iou_calculate();
    // object_publish();
    // object_clear();
  }
  return;
}

int main(int argc, char** argv) 
{
  ros::init(argc, argv, "union_detect");
  ros::NodeHandle nodeHandle_("~");
  std::string mode = "point";
  // std::string mode = "3dbox";
  std::string BoundingboxesTopicName;
  int BoundingBoxesQueueSize;
  std::string PointsTopicName;
  int pointsQueueSize;
  std::string foshan_PointsTopicName;
  int foshan_pointsQueueSize;
  std::string ImagesTopicName;
  int ImagesQueueSize;
  std::string Object_ResultTopicName;
  int Object_ResultQueueSize;
  bool Object_ResultLatch;
  std::string MappingTopicName;
  int MappingQueueSize;
  bool MappingLatch;

  nodeHandle_.param("subscribers/boundingboxes/topic", BoundingboxesTopicName, std::string("/darknet_ros/bounding_boxes"));
  nodeHandle_.param("subscribers/boundingboxes/queue_size",  BoundingBoxesQueueSize, 1);

  nodeHandle_.param("subscribers/points/topic", PointsTopicName, std::string("/perception/lidar_cluster"));
  nodeHandle_.param("subscribers/points/queue_size",  pointsQueueSize, 1);

  nodeHandle_.param("subscribers/foshan_points/topic", foshan_PointsTopicName, std::string("/filtered_points_no_ground"));
  nodeHandle_.param("subscribers/foshan_points/queue_size",  foshan_pointsQueueSize, 10);

  nodeHandle_.param("subscribers/images/topic", ImagesTopicName, std::string("/usb_cam/image_raw"));
    // nodeHandle_.param("subscribers/images/topic", ImagesTopicName, std::string("/darknet_ros/detection_image"));
  nodeHandle_.param("subscribers/images/queue_size",  ImagesQueueSize, 1);
  

  nodeHandle_.param("publishers/union_detect_result/topic", Object_ResultTopicName,
                    std::string("/union_detect/union_detect_result"));
  nodeHandle_.param("publishers/union_detect_result/queue_size", Object_ResultQueueSize, 1);
  nodeHandle_.param("publishers/union_detect_result/latch", Object_ResultLatch, true);

  nodeHandle_.param("publishers/mapping/topic", MappingTopicName, std::string("/union_detect/mapping"));
  nodeHandle_.param("publishers/mapping/queue_size", MappingQueueSize, 1);
  nodeHandle_.param("publishers/mapping/latch", MappingLatch, true);

  // boundingboxesSubscriber_ = nodeHandle_.subscribe(BoundingboxesTopicName, BoundingBoxesQueueSize, boundingboxcallback);
  // pointsSubscriber_ = nodeHandle_.subscribe(PointsTopicName,  pointsQueueSize, pointcallback);
  foshan_pointsSubscriber_ = nodeHandle_.subscribe(foshan_PointsTopicName,  foshan_pointsQueueSize, foshan_pointcallback);
  imagesSubscriber_ = nodeHandle_.subscribe(ImagesTopicName,  ImagesQueueSize, imagescallback);
  // objectspublisher_ = nodeHandle_.advertise<fsd_common_msgs::Cone>(Object_ResultTopicName,
                      // Object_ResultQueueSize,Object_ResultLatch);
  // mappingpublisher_ = nodeHandle_.advertise<sensor_msgs::Image>(MappingTopicName,
                      // MappingQueueSize,MappingLatch);

  ros::Rate loop_rate(100);
  while(ros::ok())
  {
    ros::spinOnce();
    if(!m_Img2dBoxArr.empty() && !m_Point3dArr.empty())
    // if(!m_Img2dBoxArr.empty())
    {
      union_detector(mode);
    }
    loop_rate.sleep();
  }
  return 0;
}
